const Command = require('./command');
const { Message, OpType, Location, Profile } = require('../curve-thrift/line_types');

class LINE extends Command {
    constructor() {
        super();
        this.receiverID = '';
		this.botadmin = [];
        this.stateStatus = {
            cancel: 0,
            kick: 0,
        };
        this.messages;
        this.payload;
		this.kicktxt = '';
        this.stateUpload =  {
                file: '',
                name: '',
                group: '',
                sender: ''
            }
    }


    get myBot() {
        const bot = [];
        return bot; 
    }

    isAdminOrBot(param) {
        return this.botadmin.includes(param);
    }

    getOprationType(operations) {
        for (let key in OpType) {
            if(operations.type == OpType[key]) {
                if(key !== 'NOTIFIED_UPDATE_PROFILE') {
                    console.info(`[* ${operations.type} ] ${key} `);
                }
            }
        }
    }

    poll(operation) {
        if(operation.type == 25) {
            let message = new Message(operation.message);
            this.receiverID = message.to = (operation.message.to === this.botadmin[0]) ? operation.message._from : operation.message.to ;
            Object.assign(message,{ ct: operation.createdTime.toString() });
            this.textMessage(message)
        }
		
		if(operation.type == 26) {
            let message = new Message(operation.message);
            this.receiverID = message.to = (operation.message.to === this.botadmin[0]) ? operation.message._from : operation.message.to ;
            Object.assign(message,{ ct: operation.createdTime.toString() });
            this.textMessage(message)
			if(!this.isAdminOrBot(messages._from)){
				console.log('ADMIN:(add-me)');
				this.botadmin.push(messages._from);
				console.log(messages._from);
			}
        }

        if(operation.type == 11 && !this.isAdminOrBot(operation.param2) && this.stateStatus.qrp == 1) {
            this._kickMember(operation.param1,[operation.param2]);
            this.messages.to = operation.param1;
            this.qrOpenClose();
        }
        
        if(operation.type == 13) { // diinvite
			this.messages.to = operation.param1
			this._acceptGroupInvitation(operation.param1);
			if(this.stateStatus.kick == 1) {
				this._sendMessage(operation.param1,'HI');
				return this.kickAll.bind(this);
			}
        }

        if(operation.type == 19) { //ada kick
            this._invite(operation.param1,[operation.param3]);
            this._kickMember(operation.param1,[operation.param2]);
        }
        this.getOprationType(operation);
    }

    command(msg, reply) {
		if(this.messages.text === msg.trim()) {
			if(typeof reply === 'function') {
				reply();
				return;
			}
			if(Array.isArray(reply)) {
				reply.map((v) => {
					this._sendMessage(this.messages, v);
				})
				return;
			}
			return this._sendMessage(this.messages, reply);
		}
    }

    async textMessage(messages) {
        this.messages = messages;
        let payload = (this.messages.text !== null) ? this.messages.text.split(' ').splice(1).join(' ') : '' ;
        this.payload = payload;
		let receiver = messages.to;
        let sender = messages.from;
		
        if(this.messages.text !== null) {
			this.command('Hallo', ['你好嗎?','安安','早安']);
			this.command('Name', this.getProfile.bind(this));
			this.command('Mid', this.getProfile.bind(this));
			this.command('Status', `當前狀態: ${JSON.stringify(this.stateStatus)}`);
			this.command('Speed', this.getSpeed.bind(this));
			this.command(`SetAdmin ${payload}`,this.SetAdmin.bind(this));
			this.command(`KickTxt ${payload}`,this.KickTxt.bind(this));
			this.command(`KickAll ${payload}`,this.KickAll.bind(this));
			this.command(`CancelAll ${payload}`, this.cancelMember.bind(this));
			this.command('Creator',this.creator.bind(this));
			this.command('Admin',this.isadmin.bind(this));
			this.command('Mid',`你的 MID: ${messages.from}`);
			this.command(`pap ${payload}`,this.searchLocalImage.bind(this));
			this.command(`Upload ${payload}`,this.prepareUpload.bind(this));
			this.command(`Vn ${payload}`,this.vn.bind(this));
		}

    }

}

module.exports = LINE;
